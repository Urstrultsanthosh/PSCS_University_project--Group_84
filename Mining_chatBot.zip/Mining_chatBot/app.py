from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import openai
import os
from datetime import timedelta


app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default-secret-key')
openai.api_key = os.getenv('Osk-proj-2aMc7o9UoLlkFlpnIybw3l56rHkCI4o4rMx7DzNMPz-Dh73hkBY1QBm9bTwQuow4op5gZkIsTNT3BlbkFJmB3vArNwk-8HUtx2iod4Tgsl4qS9QDyls-TOjlZj6UXQw-kj4Tnu5wXLA1ikr7bU0isVURmVsA')
app.permanent_session_lifetime = timedelta(minutes=30)


# Initialize SQLite database
def init_db():
    if not os.path.exists('database.db'):
        try:
            conn = sqlite3.connect('database.db')
            conn.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)')
            conn.close()
        except sqlite3.Error as e:
            print(f"Database error: {e}")

# Home route
@app.route('/')
def home():
    return redirect(url_for('login'))

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    invalid_credentials = False
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        con = sqlite3.connect("database.db")
        cur = con.cursor()
        cur.execute("SELECT * FROM users WHERE username=? AND password=?", (user, pwd))
        if cur.fetchone():
            session['user'] = user
            return redirect(url_for('select_language'))
        else:
            invalid_credentials = True
    return render_template('login.html', invalid_credentials=invalid_credentials)

# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        if not user or not pwd:
            return render_template('register.html', error="Username and password cannot be empty.")
        con = sqlite3.connect("database.db")
        con.execute("INSERT INTO users (username, password) VALUES (?, ?)", (user, pwd))
        con.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

# Language selection route
@app.route('/select_language', methods=['GET', 'POST'])
def select_language():
    if request.method == 'POST':
        session['language'] = request.form['language']
        return redirect(url_for('chatbot'))
    return render_template('select_language.html')

# Chatbot route
@app.route('/chatbot', methods=['GET', 'POST'])
def chatbot():
    response = ""
    if request.method == 'POST':
        user_input = request.form['query']
        language = session.get('language', 'english')
        response = ask_chatgpt(user_input, language)
    else:
        language = session.get('language', 'english')
    return render_template('chatbot.html', response=response, language=language)


# OpenAI chatbot function with mining domain filtering and language preference
def ask_chatgpt(prompt, language):
    mining_keywords = [
        "mining", "coal", "dgms", "regulation", "explosives", "colliery",
        "wages", "circulars", "cba", "la", "randr", "act", "rules",
        "payment", "mines", "proceedings", "dgms circulars", "land acquisition"
    ]
    if not any(keyword.lower() in prompt.lower() for keyword in mining_keywords):
        return "Sorry, I can only help with mining-related Acts, Rules, and Regulations."

    language_prefix = {
        "english": "Answer in English: ",
        "hindi": "हिंदी में उत्तर दें: ",
        "telugu": "తెలుగులో సమాధానం ఇవ్వండి: ",
        "kannada": "ಕನ್ನಡದಲ್ಲಿ ಉತ್ತರ ನೀಡಿ: "
    }
    full_prompt = language_prefix.get(language, '') + prompt

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": full_prompt}]
        )
        return response['choices'][0]['message']['content']
    except openai.error.OpenAIError as e:
        return f"Error communicating with OpenAI: {str(e)}"

# Logout route
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# Start the app
if __name__ == '__main__':
    init_db()
    app.run(debug=False)
